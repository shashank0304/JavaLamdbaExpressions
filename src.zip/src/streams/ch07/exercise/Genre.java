package streams.ch07.exercise;

public enum Genre {
	
		HORROR,
		COMEDY,
		ACTION,
		SUPERHERO,
		CRIME,
		MYSTERY;
}
