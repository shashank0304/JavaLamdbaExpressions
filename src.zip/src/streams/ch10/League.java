package streams.ch10;

public enum League {
	
	PREMIER_LEAGUE,
	LA_LIGA,
	BUNDESLIGA,
	CHAMPIONS_LEAGUE;

}
