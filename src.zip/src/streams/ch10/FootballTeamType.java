package streams.ch10;

public enum FootballTeamType {
	
	ATTACKING,
	DEFENSIVE

}
