package lambdas.ch02;

import lambdas.employee.Employee;

public interface EmployeeFilter {

	public boolean filterEmployee(Employee employee);

}
