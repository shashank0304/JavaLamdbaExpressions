package lambdas.ch02.exercise;

public enum PaymentStatus {
	
	SUCCESS,
	FAIL,
	PENDING;

}
