package lambdas.ch02.exercise;

public enum PaymentType {
	
	DEBIT_CARD,
	CREDIT_CARD,
	//NET_BANKING,
	CASH_ON_DELIVERY,
	//UPI;

}
