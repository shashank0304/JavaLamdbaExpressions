
  package lambdas.movie.exercise;
  
  public enum Genre {
  
  HORROR, COMEDY, ACTION, SUPERHERO, CRIME, MYSTERY; }
 