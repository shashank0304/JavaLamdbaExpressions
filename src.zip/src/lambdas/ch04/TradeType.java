package lambdas.ch04;

public enum TradeType {
	
	BUY,
	SELL;

}
