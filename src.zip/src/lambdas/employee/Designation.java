package lambdas.employee;

public enum Designation {
	
	DEVELOPER,
	TECHNICAL_LEAD,
	ARCHITECT,
	MANAGER;

}
