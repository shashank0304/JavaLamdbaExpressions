package lambdas.employee;

public enum Skill {
	
	JAVA,
	MICROSOFT,
	PYTHON,
	JAVASCRIPT,
	ANGULARJS,
	NODE,
	SPRING,
	PMP,
	DESIGN,
	JPA;
	

}
