package lambdas.ch03.exercise;

public interface NumberFilter {

	public boolean filterNumber(Integer number);

}
